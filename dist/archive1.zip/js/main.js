console.log('hello')

var arr = ['These', 'are', 'contents', 'of', 'an', 'array'];

// for ( var i = 0; i < arr.length; i++ ) {
//   console.log('hello loop')
//   console.log(arr[i])

  // document.getElementById('demo').innerHTML = arr[i];
// }